# ==============================================================================
# Script di creazione pacchetto di deploy per exprivia-prenotazione-posti
# ==============================================================================

$sourcePath = Get-Location
$zipPath = Join-Path $sourcePath "deploy-package.zip"
$tempDir = Join-Path $sourcePath "temp_deploy_staging"

# Rimuovi file zip precedente se esiste
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

# Pulisci cartella temporanea se esiste
if (Test-Path $tempDir) {
    Remove-Item $tempDir -Recurse -Force
}

# Crea la cartella temporanea
New-Item -ItemType Directory -Path $tempDir | Out-Null

# Copia i file escludendo le cartelle pesanti
# Robocopy è uno strumento integrato in Windows molto veloce ed efficiente
robocopy "$sourcePath" "$tempDir" /E /XD .git node_modules target .angular .vscode .idea temp_deploy_staging /XF deploy-package.zip build.log package-lock.json | Out-Null

# Comprimi il contenuto della cartella temporanea nel file ZIP
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipPath -Force

# Rimuovi la cartella temporanea
Remove-Item $tempDir -Recurse -Force

Write-Host "--------------------------------------------------------" -ForegroundColor Green
Write-Host " Pacchetto di deploy creato con successo!" -ForegroundColor Green
Write-Host " File: deploy-package.zip" -ForegroundColor Green
Write-Host " Ora puoi caricare questo singolo file ZIP tramite FileZilla." -ForegroundColor Green
Write-Host "--------------------------------------------------------" -ForegroundColor Green
