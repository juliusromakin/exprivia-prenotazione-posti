import { Routes } from "@angular/router";
import { DashboardComponent } from "./dashboard.component";
import { UserRouteAccessService } from "../../core/auth/user-route-access.service";

export const DASHBOARD_ROUTES: Routes = [
  {
    path: "",
    component: DashboardComponent,
    children: [
      {
        path: "user-management",
        loadComponent: () =>
          import("./user-management/user-list.component").then(
            (m) => m.UserListComponent
          ),
        data: { badges: ["ROLE_ADMIN"] },
        canActivate: [UserRouteAccessService],
      },
      {
        path: "workspace-booking",
        loadComponent: () =>
          import(
            "./prenotazione-posizione/prenotazione-posizione.component"
          ).then((m) => m.PrenotazionePosizioneComponent),
        data: { badges: ["ROLE_USER", "ROLE_ADMIN"] },
        canActivate: [UserRouteAccessService],
      },
      {
        path: "bookings",
        loadComponent: () =>
          import("./user-bookings/user-bookings.component").then(
            (m) => m.UserBookingsComponent
          ),
        data: { badges: ["ROLE_ADMIN"] },
        canActivate: [UserRouteAccessService],
      },
      {
        path: "update-user",
        loadComponent: () =>
          import("../../account/update-user/update-user.component").then(
            (m) => m.UpdateUserComponent
          ),
        data: { badges: ["ROLE_ADMIN", "ROLE_USER"] },
        canActivate: [UserRouteAccessService],
      },
      {
        path: "statistics",
        loadComponent: () =>
          import("./stats/stats.component").then(
            (m) => m.StatsComponent
          ),
        data: { badges: ["ROLE_ADMIN"] },
        canActivate: [UserRouteAccessService],
      },
      {
        path: "badge-management",
        loadComponent: () =>
          import("./badge-management/badge-management.component").then(
            (m) => m.BadgeManagementComponent
          ),
        data: { badges: ["ROLE_ADMIN"] },
        canActivate: [UserRouteAccessService],
      },
      {
        path: "gestione-sedi",
        loadComponent: () =>
          import("./gestione-sedi/gestione-sedi.component").then(
            (m) => m.GestioneSediComponent
          ),
        data: { badges: ["ROLE_ADMIN"] },
        canActivate: [UserRouteAccessService],
      },
    ],
  },
];
